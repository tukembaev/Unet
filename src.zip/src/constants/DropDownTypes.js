//Contstans for dropdown component
export const raportTypeZav = [
  { id: 1, label: "Рапорт" },
  { id: 2, label: "Ремонт" },
  { id: 4, label: "Оргтехника" },
  { id: 3, label: "Требование" },
  { id: 5, label: "Списание" },
];

export const raportTypeUser = [
  { id: 1, label: "Рапорт" },
  { id: 2, label: "Ремонт" },
  { id: 4, label: "Оргтехника" },
  { id: 3, label: "Требование" },
];

export const directionsRepair = [
  { id: 1, label: "Строительная служба" },
  { id: 2, label: "Служба электрики" },
  { id: 3, label: "Служба сантехники" },
];

export const directionsOrgTech = [
  { id: 1, label: "Ремонт ПК", first: "232", value: 1 },
  { id: 2, label: "Установка OS", first: "232", value: 2 },
  { id: 3, label: "Сборка ПК", first: "232", value: 3 },
  { id: 4, label: "Заправка картриджа", first: "232", value: 4 },
];

export const directionsWriteOff = [
  { id: 1, label: "Основные" },
  { id: 2, label: "Малоценные и быстроизнашивающиеся предметы (МБП)" },
];

export const typeOfClass = [
  { value: "Очная", label: "Очная" },
  { value: "Заочная", label: "Заочная" },
];

export const years = [
  { value: 2019 - 2020, label: "2019-2020" },
  { value: 2020 - 2021, label: "2020-2021" },
  { value: 2021 - 2022, label: "2021-2022" },
  { value: 2022 - 2023, label: "2022-2023" },
  { value: 2023 - 2024, label: "2023-2024" },
];
