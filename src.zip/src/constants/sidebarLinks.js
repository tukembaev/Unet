export let statementLinks = [
{
    text: "Создать заявление",
    to: "/create-statement",
},
{
    text: "История заявлений",
    to: "/statement-history",
},
{
    text: "Статус заявлений",
    to: "/statements",
}
];
export let taskLinks = [
{
    text: "Добавить задачу",
    to: "/create-task",
},
{
    text: "Мои задачи",
    to: "/tasks",
},
];