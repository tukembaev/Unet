export const term = {
    overdue: "overdue",
    today: "today",
    week: "week",
    mounth: "mounth",
    longrange: "longrange",
    noDeadline: "noDeadline"
}