import React from "react";
import Header from "../Header/Header";
import Sidebar from "../Sidebar/Sidebar";
import { useAuth } from "../../../hooks/useAuth";
import styles from "./Layout.module.scss";
import Menu from "../Sidebar/components/Menu/Menu";
import { useEffect } from "react";
import { useState } from "react";
import { useMemo } from "react";
import { useSelector } from "react-redux";

function Layout({ children }) {
  // states
  const { isAuth } = useAuth();
  const [width, setWidth] = useState(window.innerWidth);
  const [render , setRender] = useState(false);
  const [backgroundImage , setBackgroundImage] = useState(localStorage.getItem("bacground"));
  // functions
  useEffect(() => {
    setRender(true)
    function handleResize() {
      setWidth(window.innerWidth);
    }
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [width]);

  return (
    <div> 
      {width >= 1000 ?  <Sidebar /> : null} 
   
    <div className={styles.layout__wrapper} style={{backgroundImage:`url(${backgroundImage})` , objectFit: 'cover'}}>

      <div className={styles.body__wrapper}>
        <Header width={width} setBackgroundImage={setBackgroundImage}/>
        <div>{children}</div>
      </div>
    </div>

    <div className={styles.layout__wrapper2} style={{backgroundImage:`url(${backgroundImage})` , objectFit: 'cover'}}>
    
      <Header width={width} setBackgroundImage={setBackgroundImage}/>
      <div className={styles.body__wrapper}> 
        <div>{children}</div>
      </div>
    </div>
  </div>
  );
}

export default Layout;
