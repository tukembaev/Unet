export { default as Login } from './Login/Login';
export { default as MainPage } from './MainPage/MainPage';
export { default as TasksPage } from './TasksPage/TasksPage';
export { default as StatementPage } from './StatementPage/StatementPage';
export { default as QrcodePage } from './QrcodePage/QrcodePage';