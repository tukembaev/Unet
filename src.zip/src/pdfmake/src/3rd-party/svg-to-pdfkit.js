var SVGtoPDF = require('./svg-to-pdfkit/source.js');

module.exports = SVGtoPDF;
