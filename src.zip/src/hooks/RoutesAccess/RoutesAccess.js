import { useContext } from "react";
import { createContext } from "react";


const TariffContext = createContext(); 
export const TariffData = () => useContext(TariffContext);

export const RoutesAccess = (routes) =>{
//states
const accessAllowed = false;

}

