import React from 'react'
import { Layout } from '../components'

const Developing = () => {
  return (
    <Layout>
        <h1 style={{color: "white"}}>Этот раздел находится в разработке...</h1>
    </Layout>
  )
}

export default Developing